$(document).ready(function() {

    console.log("BLOG");
    
})